<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/', function () {
    return view('pages.home');
});

Route::get('/dataproduct', 'dataproductController@index');

Route::get('/datasuplier', 'dataController@index');

Route::get('/cekin', 'cekinController@index');

Route::get('/cekout', 'cekoutController@index');

Route::get('/suplier', 'suplierController@index');

Route::get('/tambah_dataproduct', function () {
    return view('pages.tambah_dataproduct');
});

Route::get('/welcome', function () {
    return view('pages.welcome');
});


Route::post('/tambah_dataproduct/store','dataproductController@store');


Route::get('/tambah_datacekin','cekinController@create');

Route::post('/tambah_datacekin/store','cekinController@store');


Route::get('/tambah_datacekout','cekoutController@create');

Route::post('/tambah_datacekout/store','cekoutController@update');


Route::get('/tambah_datasuplier','suplierController@create');

Route::post('/tambah_datasuplier/store','suplierController@store');


Route::get('/dataproduct/edit/{id}', 'dataproductController@edit');

Route::put('/dataproduct/update/{id}', 'dataproductController@update');

Route::get('/dataproduct/delete/{id}', 'dataproductController@destroy');


Route::get('/datacekin/edit/{id}', 'cekinController@edit');

Route::put('/datacekin/update/{id}', 'cekinController@update');

Route::get('/datacekin/delete/{id}', 'cekinController@destroy');


Route::get('/datacekout/edit/{id}', 'cekoutController@edit');

Route::put('/datacekout/update/{id}', 'cekoutController@update');

Route::get('/datacekout/delete/{id}', 'cekoutController@destroy');


Route::get('/datasuplier/edit/{id}', 'suplierController@edit');

Route::put('/datasuplier/update/{id}', 'suplierController@update');

Route::get('/datasuplier/delete/{id}', 'suplierController@destroy');
