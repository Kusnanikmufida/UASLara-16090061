<div id="about">
	<h2>About</h2>
	<p>Politeknik Harapan Bersama merupakan salah satu PTS di kota Tegal.
	   Politeknik  Tegal terdiri dari beberapa program studi, salah satunya program studi
	   <b>Sarjana Terapan Teknik Informatika</b>.</p>	
</div>