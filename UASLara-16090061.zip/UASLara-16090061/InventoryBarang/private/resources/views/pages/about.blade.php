@extends('template')

@section('main')
<div id="about">
	<h2>Profil</h2>
	<p>Program Sarjana Terapan Teknik Informatika
	Politenik Harapan Bersama Kota Tegal.</p>
</div>
@stop

@section('footer')
<div id="footer">
	<p>&copy; 2019 | Frameork Programming Poltek Tegal</p>
</div>
@stop