@extends('dashboard')

@section('content')
<div class="row">
                    <!-- ============================================================== -->
                    <!-- basic table  -->
                    <!-- ============================================================== -->
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="card">
                            <h5 class="card-header">Data Suplier</h5>
                            <div class="card-body">
                    	<a href="{{ url('tambah_datasuplier') }}">
                            <button class="btn btn-info" style="margin-right: 900px">+Tambah</button>
                        </a>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered first">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Nama Suplier</th>
                                                <th>Alamat</th>
                                                <th>No Hp</th>   
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @php $no=1 @endphp
                                             @foreach($suplier as $p)
                                                <tr>
                                                <td>{{ $no++}}</td>
                                                <td>{{ $p->nama_suplier }}</td>
                                                <td>{{ $p->alamat }}</td>
                                                <td>{{ $p->no_hp }}</td>
                                            <td>
                                                <a href="{{url('/datasuplier/edit/'.$p->id) }}"class="btn btn-info">Edit</a>

                                                <a href="{{url('/datasuplier/delete/'.$p->id) }}"class="btn btn-info">Hapus</a>
                                            </td>
                                        </tr>
                                         @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end basic table  -->
                    <!-- ============================================================== -->
                </div>
                @stop