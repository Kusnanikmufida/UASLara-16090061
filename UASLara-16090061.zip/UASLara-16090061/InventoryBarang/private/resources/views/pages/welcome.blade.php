@extends('pages.admin.dash')
@section('main')
<div> class="card wow fadeIn">
	
	<div> class="card-body justify-content-between">
		
	<h2>Welcome</h2>	
</div></div>
@stop

@section('footer')
@stop