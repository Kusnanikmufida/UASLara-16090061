@extends('dashboard')

@section('content')
<div class="row">
                    <!-- ============================================================== -->
                    <!-- basic table  -->
                    <!-- ============================================================== -->
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="card">
                            <h5 class="card-header">Data Product</h5>
                            <div class="card-body">
                    	<a href="{{ url('tambah_dataproduct') }}">
                            <button class="btn btn-info" style="margin-right: 900px">+Tambah</button>
                        </a>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered first">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Nama Barang</th>
                                                <th>Brand</th>
                                                <th>Warna</th>
                                                <th>Harga</th>
                                                <th>Stok</th>
                                                <th>No Rak</th>
                                                <th>ID Suplier</th>
                                                <th>Action</th>
                                               
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @php $no=1 @endphp
                                             @foreach($dataproduct as $p)
                                                <tr>
                                                <td>{{ $no++}}</td>
                                                <td>{{ $p->nama_barang }}</td>
                                                <td>{{ $p->brand }}</td>
                                                <td>{{ $p->warna }}</td>
                                                <td>{{ $p->harga }}</td>
                                                <td>{{ $p->stok }}</td>
                                                <td>{{ $p->no_rak }}</td>
                                                <td>{{ $p->id_suplier }}</td>
                                            <td>
                                                <a href="{{url('/dataproduct/edit/'.$p->id) }}"class="btn btn-info">Edit</a>
                |
                                                <a href="{{url('/dataproduct/delete/'.$p->id) }}"class="btn btn-info">Hapus</a>
                                            </td>
                                        </tr>
                                         @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end basic table  -->
                    <!-- ============================================================== -->
                </div>
                @stop