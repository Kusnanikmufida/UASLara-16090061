@extends('dashboard')

@section('content')
<div id="barang">
 <div class='col-xs-12'>
                    <div class="page-title">


	<div class="col-xs-12">
                    <section class="box ">
                        <header class="panel_header">
                            <h2 class="title pull-left">Tambah Data Cek In Barang</h2>
                        </header>
                        <div class="content-body">
                            <div class="row">
                                <div class="col-md-8 col-sm-9 col-xs-10">
                                	<form action="{{ url('/tambah_datacekin/store') }}" method="post">
                                		@csrf

                                    <div class="form-group">
                                        <label class="form-label" for="field-3">Nama Barang</label>
                                        <div class="controls">
                                            <input type="text" class="form-control" name="nama_barang">
                                    </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label" for="field-3">Jumlah Barang</label>
                                        <div class="controls">
                                            <input type="text" class="form-control" name="jumlah_barang">
                                    </div>
                                    </div>

                                        <div class="form-group">
                                        <table>
                                            <tbody>
                                                <tr>
                                                    <td>
                    
                                                        <button type="submit" class="btn btn-primary">Submit</button>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                            
                                        </div>
                                        </form>
                                    

@endsection