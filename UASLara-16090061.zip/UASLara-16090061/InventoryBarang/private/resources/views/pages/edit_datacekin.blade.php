@extends('dashboard')

@section('content')
<div id="barang">
 <div class='col-xs-12'>
                    <div class="page-title">


	<div class="col-xs-12">
                    <section class="box ">
                        <header class="panel_header">
                            <h2 class="title pull-left">Tambah Data Cek In</h2>
                        </header>
                        <div class="content-body">
                            <div class="row">
                                <div class="col-md-8 col-sm-9 col-xs-10">
                                	<form action="{{url('/datacekin/update/'.$datacekin->id)}}" method="post">
                                		@csrf
                                        @method('PUT')

                                    <div class="form-group">
                                        <label class="form-label" for="field-1">Nama Barang</label>
                                        <div class="controls">
                                            <input type="text" value="{{ $datacekin->nama_barang}}" class="form-control" name="nama_barang">
                                    </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label" for="field-3">Jumlah Barang</label>
                                        <div class="controls">
                                            <input type="text" value="{{$datacekin->jumlah_barang}}"class="form-control" name="jumlah_barang">
                                    </div>
                                    </div>

                                        <div class="form-group">

                                                        <input type="submit" value="Submit" class="btn btn-primary">
                                            
                                        </div>
                                        </form>
                                    

@endsection