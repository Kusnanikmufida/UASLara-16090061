@extends('dashboard')

@section('content')
<div class="row">
                    <!-- ============================================================== -->
                    <!-- basic table  -->
                    <!-- ============================================================== -->
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="card">
                            <h5 class="card-header"> Cek Out</h5>
                            <div class="card-body">
                                      <a href="{{ url('tambah_datacekout') }}">
                        <button class="btn btn-info" style="margin-right: 900px">+Tambah</button> 
                    </a>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered first">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Nama Barang</th>
                                                <th>Jumlah Barang</th>
                                                <th>Action</th>
                                               
                                            </tr>
                                        </thead>
                                        <tbody>
                                                 @php $no=1 @endphp
                                                @foreach($cekout as $p)
                                                <tr>
                                                    <td>{{ $no++}}</td>
                                                    <td>{{ $p->nama_barang }}</td>
                                                    <td>{{ $p->jumlah_barang }}</td>
                                                <td>
                                                    <a href="{{url('/datacekout/edit/'.$p->id) }}"class="btn btn-info">Edit</a>

                                                    <a href="{{url('/datacekout/delete/'.$p->id) }}"class="btn btn-info">Hapus</a>
                                                </td>
                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end basic table  -->
                    <!-- ============================================================== -->
                </div>
                @stop