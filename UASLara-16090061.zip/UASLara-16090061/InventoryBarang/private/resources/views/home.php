<div id="home">
	<h2>Homepage</h2>
	<p>Selamat datang di Politeknik  Harapan Bersama Tegal.</p>
</div>
