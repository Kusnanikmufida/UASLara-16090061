<?php /* C:\xampp\htdocs\Admin\private\resources\views/pages/tambah_dataproduct.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div id="barang">
 <div class='col-xs-12'>
                    <div class="page-title">


	<div class="col-xs-12">
                    <section class="box ">
                        <header class="panel_header">
                            <h2 class="title pull-left">Tambah Data Product</h2>
                        </header>
                        <div class="content-body">
                            <div class="row">
                                <div class="col-md-8 col-sm-9 col-xs-10">
                                	<form action="<?php echo e(url('/tambah_dataproduct/store')); ?>" method="post">
                                		<?php echo csrf_field(); ?>

                                    <div class="form-group">
                                        <label class="form-label" for="field-1">Nama Barang</label>
                                        <div class="controls">
                                            <input type="text" class="form-control" name="nama_barang">
                                    </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label" for="field-3">Brand</label>
                                        <div class="controls">
                                            <input type="text" class="form-control" name="brand">
                                    </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label" for="field-3">Warna</label>
                                        <div class="controls">
                                            <input type="text" class="form-control" name="warna">
                                    </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label" for="field-3">Harga</label>
                                        <div class="controls">
                                            <input type="text" class="form-control" name="harga">
                                    </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label" for="field-3">Stok</label>
                                        <div class="controls">
                                            <input type="text" class="form-control" name="stok">
                                    </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label" for="field-3">No Rak</label>
                                        <div class="controls">
                                            <input type="text" class="form-control" name="no_rak">
                                    </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label" for="field-3">ID Suplier</label>
                                        <div class="controls">
                                            <input type="text" class="form-control" name="id_suplier">
                                    </div>
                                    </div>

                                        <div class="form-group">
            
                                                        <a href="<?php echo e(url('dataproduct')); ?>"></a>
                                                        <input type="submit" value="Submit" class="btn btn-primary">
                                            
                                        </div>
                                        </form>
                                    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>