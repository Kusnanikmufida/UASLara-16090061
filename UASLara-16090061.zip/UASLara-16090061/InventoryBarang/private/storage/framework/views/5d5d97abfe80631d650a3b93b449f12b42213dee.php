<?php /* C:\xampp\htdocs\Laravel\private\resources\views/pages/datasatuan.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="row">
                    <!-- ============================================================== -->
                    <!-- basic table  -->
                    <!-- ============================================================== -->
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="card">
                            <h5 class="card-header">Data Satuan</h5>
                            <div class="card-body">
                    	<button class="btn btn-info" style="margin-left: 900px">Tambah</button>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered first">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Satuan</th>
                                                <th>Action</th>
                                               
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>1.</td>
                                                <td>PCS</td>
                                                <td><button class="btn btn-info">Edit</button>     <button class="btn btn-info">Delete</button></td>
                                                
                                           
                                            </tr>
                                            <tr>
                                                <td>2.</td>
                                                <td>PAK</td>
                                              <td><button class="btn btn-info">Edit</button>     <button class="btn btn-info">Delete</button></td>
                                                
                                              
                                            
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end basic table  -->
                    <!-- ============================================================== -->
                </div>
                <?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>