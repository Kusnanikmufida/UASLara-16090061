<?php /* C:\xampp\htdocs\Laravel\private\resources\views/pages/formbarangkeluar.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                <div class="section-block" id="formdatasuplier">
                                    <h3 class="section-title">Form Barang Keluar</h3>
                                   
                                </div>
                                <div class="card">
                                    
                                    <div class="card-body">
                                        <form>
                                            <table>
                                                <thead>
                                                    <tr>
                                                        <th>Kode</th>
                                                        <th>Tanggal</th>
                                                        <th>Department</th>
                                                       
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                <tr>
                                                    <td><input id="inputText3" type="text" class="form-control" placeholder="BK0001"></td>
                                                    <td><input id="inputEmail" type="email" placeholder="2019-04-20" class="form-control"></td>
                                                    <td><input id="inputText3" type="text" class="form-control" placeholder="Informatika"></td>
                                                </tr>
                                                </tbody>
                                            </table>
                                            <td><button class="btn btn-info">Kembali</button></td>
                                        </form>

                                        <form>
                                            <table>
                                                <thead>
                                                    <tr>
                                                        <th>Nama Barang</th>
                                                        <th>Satuan</th>
                                                        <th>City</th>
                                                        <th>Stock</th>   
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                <tr>
                                                    <td><input id="inputText3" type="text" class="form-control" placeholder=""></td>
                                                    <td><input id="inputEmail" type="email" placeholder="" class="form-control"></td>
                                                    <td><input id="inputText3" type="text" class="form-control" placeholder=""></td>
                                                    <td><input id="inputText3" type="text" class="form-control" placeholder=""></td>
                                            <td><button class="btn btn-info">Save</button></td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </form>
                                    </div>
                                    
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>