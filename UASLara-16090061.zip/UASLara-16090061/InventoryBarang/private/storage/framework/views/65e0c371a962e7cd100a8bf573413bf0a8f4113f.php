<?php /* C:\xampp\htdocs\Admin\private\resources\views/pages/cekout.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="row">
                    <!-- ============================================================== -->
                    <!-- basic table  -->
                    <!-- ============================================================== -->
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="card">
                            <h5 class="card-header"> Cek Out</h5>
                            <div class="card-body">
                                      <a href="<?php echo e(url('tambah_datacekout')); ?>">
                        <button class="btn btn-info" style="margin-right: 900px">+Tambah</button> 
                    </a>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered first">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Nama Barang</th>
                                                <th>Jumlah Barang</th>
                                                <th>Action</th>
                                               
                                            </tr>
                                        </thead>
                                        <tbody>
                                                 <?php $no=1 ?>
                                                <?php $__currentLoopData = $cekout; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($no++); ?></td>
                                                    <td><?php echo e($p->nama_barang); ?></td>
                                                    <td><?php echo e($p->jumlah_barang); ?></td>
                                                <td>
                                                    <a href="<?php echo e(url('/datacekout/edit/'.$p->id)); ?>"class="btn btn-info">Edit</a>

                                                    <a href="<?php echo e(url('/datacekout/delete/'.$p->id)); ?>"class="btn btn-info">Hapus</a>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end basic table  -->
                    <!-- ============================================================== -->
                </div>
                <?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>