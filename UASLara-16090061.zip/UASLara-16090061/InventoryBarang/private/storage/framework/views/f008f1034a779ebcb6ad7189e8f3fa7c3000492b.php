<?php /* C:\xampp\htdocs\Admin\private\resources\views/pages/laporanbarangkeluar.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                <div class="section-block" id="laporanbarangkeluar">
                                    <h3 class="section-title">Laporan Barang Keluar</h3>
                                   
                                </div>
                                <div class="card">
                                    
                                    <div class="card-body">
                                        <form>
                                            <div class="form-group">
                                                <label for="inputText3" class="col-form-label">Dari</label>
                                                <input id="inputText3" type="text" class="form-control" placeholder="S001">
                                            </div>
                                            <div class="form-group">
                                                <label for="inputEmail">Sampai</label>
                                                <input id="inputEmail" type="email" placeholder="kusnanik" class="form-control">
                                            
                                            <td><button class="btn btn-info">Edit</button>     <button class="btn btn-info">Delete</button></td>
                                            
                                        </form>
                                    </div>
                                    
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                <?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>