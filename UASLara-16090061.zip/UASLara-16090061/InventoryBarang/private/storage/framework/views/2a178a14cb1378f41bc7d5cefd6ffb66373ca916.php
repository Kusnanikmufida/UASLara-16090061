<?php /* C:\xampp\htdocs\Admin\private\resources\views/pages/dataproduct.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="row">
                    <!-- ============================================================== -->
                    <!-- basic table  -->
                    <!-- ============================================================== -->
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="card">
                            <h5 class="card-header">Data Product</h5>
                            <div class="card-body">
                    	<a href="<?php echo e(url('tambah_dataproduct')); ?>">
                            <button class="btn btn-info" style="margin-right: 900px">+Tambah</button>
                        </a>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered first">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Nama Barang</th>
                                                <th>Brand</th>
                                                <th>Warna</th>
                                                <th>Harga</th>
                                                <th>Stok</th>
                                                <th>No Rak</th>
                                                <th>ID Suplier</th>
                                                <th>Action</th>
                                               
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $no=1 ?>
                                             <?php $__currentLoopData = $dataproduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                <td><?php echo e($no++); ?></td>
                                                <td><?php echo e($p->nama_barang); ?></td>
                                                <td><?php echo e($p->brand); ?></td>
                                                <td><?php echo e($p->warna); ?></td>
                                                <td><?php echo e($p->harga); ?></td>
                                                <td><?php echo e($p->stok); ?></td>
                                                <td><?php echo e($p->no_rak); ?></td>
                                                <td><?php echo e($p->id_suplier); ?></td>
                                            <td>
                                                <a href="<?php echo e(url('/dataproduct/edit/'.$p->id)); ?>"class="btn btn-info">Edit</a>
                |
                                                <a href="<?php echo e(url('/dataproduct/delete/'.$p->id)); ?>"class="btn btn-info">Hapus</a>
                                            </td>
                                        </tr>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end basic table  -->
                    <!-- ============================================================== -->
                </div>
                <?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>