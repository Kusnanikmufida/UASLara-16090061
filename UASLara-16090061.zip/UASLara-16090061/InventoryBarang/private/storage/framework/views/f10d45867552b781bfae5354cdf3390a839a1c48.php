<?php /* C:\xampp\htdocs\Admin\private\resources\views/pages/tambah_barangkeluar.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div id="barang">
 <div class='col-xs-12'>
                    <div class="page-title">


	<div class="col-xs-12">
                    <section class="box ">
                        <header class="panel_header">
                            <h2 class="title pull-left">Tambah Data Barang Keluar</h2>
                        </header>
                        <div class="content-body">
                            <div class="row">
                                <div class="col-md-8 col-sm-9 col-xs-10">
                                	<form action="" method="post">
                                		<?php echo csrf_field(); ?>

                                    <div class="form-group">
                                        <label class="form-label" for="field-3">Tanggal Masuk</label>
                                        <div class="controls">
                                            <input type="date" class="form-control" name="berangkat">
                                    </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label" for="field-3">Pengambil</label>
                                        <div class="controls">
                                            <input type="text" class="form-control" name="tujuan">
                                    </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label" for="field-3">Divisi</label>
                                        <div class="controls">
                                            <input type="text" class="form-control" name="harga">
                                    </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label" for="field-3">Nama Barang</label>
                                        <div class="controls">
                                            <input type="text" class="form-control" name="harga">
                                    </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label" for="field-3">Stok</label>
                                        <div class="controls">
                                            <input type="text" class="form-control" name="harga">
                                    </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label" for="field-3">Jumlah Keluar</label>
                                        <div class="controls">
                                            <input type="text" class="form-control" name="harga">
                                    </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label" for="field-3">Sisa Stok</label>
                                        <div class="controls">
                                            <input type="text" class="form-control" name="harga">
                                    </div>
                                    </div>



                                        <div class="form-group">
                                        <div class="controls">
                                            <a href="<?php echo e(url('barangkeluar')); ?>"><button class="btn btn-primary">Simpan</button></a>
                                        </div>
                                        </form>
                                    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>