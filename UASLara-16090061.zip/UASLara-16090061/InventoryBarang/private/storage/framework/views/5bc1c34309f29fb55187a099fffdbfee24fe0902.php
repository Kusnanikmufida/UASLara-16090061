<?php /* C:\xampp\htdocs\Admin\private\resources\views/pages/dashboard.blade.php */ ?>
<?php $__env->startSection('main'); ?>
<div> class="card wow fadeIn">
	
	<div> class="card-body justify-content-between">
		
	<h2>Selamat Datang Di Aplikasi Inventory Gudang</h2>	
</div></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.admin.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>