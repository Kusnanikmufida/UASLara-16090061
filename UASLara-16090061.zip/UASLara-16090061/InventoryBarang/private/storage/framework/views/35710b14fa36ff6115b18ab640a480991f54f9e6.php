<?php /* C:\xampp\htdocs\Admin\private\resources\views/pages/tambah_databarang.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div id="barang">
 <div class='col-xs-12'>
                    <div class="page-title">


	<div class="col-xs-12">
                    <section class="box ">
                        <header class="panel_header">
                            <h2 class="title pull-left">Tambah Data Barang</h2>
                        </header>
                        <div class="content-body">
                            <div class="row">
                                <div class="col-md-8 col-sm-9 col-xs-10">
                                	<form action="<?php echo e(url('/tambah_databarang/store')); ?>" method="post">
                                		<?php echo csrf_field(); ?>

                                    <div class="form-group">
                                        <label class="form-label" for="field-1">Nama Barang</label>
                                        <div class="controls">
                                            <input type="text" class="form-control" name="nama_barang">
                                    </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label" for="field-3">Jenis Barang</label>
                                        <div class="controls">
                                            <input type="text" class="form-control" name="jenis_barang">
                                    </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label" for="field-3">Stok</label>
                                        <div class="controls">
                                            <input type="text" class="form-control" name="stok">
                                    </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label" for="field-3">Satuan</label>
                                        <div class="controls">
                                            <input type="text" class="form-control" name="satuan">
                                    </div>
                                    </div>

                                        <div class="form-group">
            
                                                        <a href="<?php echo e(url('databarang')); ?>"></a>
                                                        <input type="submit" value="Submit" class="btn btn-primary">
                                            
                                        </div>
                                        </form>
                                    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>