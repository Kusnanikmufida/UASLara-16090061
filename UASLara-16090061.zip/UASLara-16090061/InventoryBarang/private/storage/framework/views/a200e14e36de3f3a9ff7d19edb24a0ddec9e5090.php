<?php /* C:\xampp\htdocs\Admin\private\resources\views/pages/transaksipembelian.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="row">
                    <!-- ============================================================== -->
                    <!-- basic table  -->
                    <!-- ============================================================== -->
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="card">
                            <h5 class="card-header">Transaksi Pembelian</h5>
                            <div class="card-body">
                    	<button class="btn btn-info" style="margin-left: 900px">Tambah</button>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered first">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Kode</th>
                                                <th>Tanggal</th>
                                                <th>Suplier</th>
                                                <th>Item</th>
                                                <th>Action</th>
                                               
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>1.</td>
                                                <td>BL0001</td>
                                                <td>2019-04-20</td>
                                                <td>kusnanik</td>
                                                <td>2</td>
                                                <td><button class="btn btn-info">Edit</button>     <button class="btn btn-info">Delete</button></td>
                                                
                                           
                                            </tr>
                                            <tr>
                                                <td>2.</td>
                                                <td>BL0002</td>
                                                <td>2019-04-21</td>
                                                <td>fida</td>
                                                <td>3</td>
                                              <td><button class="btn btn-info">Edit</button>     <button class="btn btn-info">Delete</button></td>
                                                
                                              
                                            
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end basic table  -->
                    <!-- ============================================================== -->
                </div>
                <?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>