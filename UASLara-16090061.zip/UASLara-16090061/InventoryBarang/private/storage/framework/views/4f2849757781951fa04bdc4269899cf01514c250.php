<?php /* C:\xampp\htdocs\Admin\private\resources\views/pages/stokbarang.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="row">
                    <!-- ============================================================== -->
                    <!-- basic table  -->
                    <!-- ============================================================== -->
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="card">
                            <h5 class="card-header">Stok Barang</h5>
                            <div class="card-body">
                        <button class="btn btn-info" style="margin-right: 900px">Cetak</button>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered first">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Nama Barang</th>
                                                <th>Jenis Barang</th>
                                                <th>Stok</th>
                                                <th>Satuan</th>
                                               
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>1.</td>
                                                <td>Buku</td>
                                                <td>Kertas</td>
                                                <td>5</td>
                                                <td>Pack</td>
                                               <!--  <td><button class="btn btn-info">Edit</button>     <button class="btn btn-info">Delete</button></td> -->
                                                
                                           
                                            </tr>
                                            <tr>
                                                <td>2.</td>
                                                <td>Spidol</td>
                                                <td>Alat Tulis</td>
                                                <td>10</td>
                                                <td>Pack</td>
                                             <!--  <td><button class="btn btn-info">Edit</button>     <button class="btn btn-info">Delete</button></td> -->
                                                
                                              
                                            
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end basic table  -->
                    <!-- ============================================================== -->
                </div>
                <?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>