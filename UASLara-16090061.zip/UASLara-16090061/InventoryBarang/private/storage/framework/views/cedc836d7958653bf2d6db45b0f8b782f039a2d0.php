<?php /* C:\xampp\htdocs\Admin\private\resources\views/pages/databarang.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="row">
                    <!-- ============================================================== -->
                    <!-- basic table  -->
                    <!-- ============================================================== -->
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="card">
                            <h5 class="card-header">Data Barang</h5>
                            <div class="card-body">
                    	<a href="<?php echo e(url('tambah_databarang')); ?>">
                            <button class="btn btn-info" style="margin-right: 900px">+Tambah</button>
                        </a>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered first">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Nama Barang</th>
                                                <th>Jenis Barang</th>
                                                <th>Stok</th>
                                                <th>Satuan</th>
                                                <th>Action</th>
                                               
                                            </tr>
                                        </thead>
                                        <tbody>
                                             <?php $__currentLoopData = $databarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                <td></td>
                                                <td><?php echo e($p->nama_barang); ?></td>
                                                <td><?php echo e($p->jenis_barang); ?></td>
                                                <td><?php echo e($p->stok); ?></td>
                                                <td><?php echo e($p->satuan); ?></td>
                                            <td>
                                                <a href="/dataabarang/edit/<?php echo e($p->id); ?>">Edit</a>
                |
                                                <a href="/dataabarang/hapus/<?php echo e($p->id); ?>">Hapus</a>
                                            </td>
                                        </tr>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end basic table  -->
                    <!-- ============================================================== -->
                </div>
                <?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>