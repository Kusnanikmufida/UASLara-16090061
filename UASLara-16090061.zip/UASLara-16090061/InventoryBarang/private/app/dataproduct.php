<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * 
 */
class dataproduct extends Model
{
	protected $table='dataproduct';
	protected $guarded = [];
	protected $fillable = ['nama_barang','brand','warna','harga','stok','no_rak','id_suplier'];
}