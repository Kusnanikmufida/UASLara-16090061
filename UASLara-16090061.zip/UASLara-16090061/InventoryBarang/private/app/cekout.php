<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cekout extends Model
{
    protected $table='cekout';
	protected $guarded = [];
	protected $fillable = ['nama_barang','jumlah_barang'];
}
