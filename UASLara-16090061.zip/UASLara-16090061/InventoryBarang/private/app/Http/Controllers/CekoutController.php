<?php

namespace App\Http\Controllers;

use App\cekout;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CekoutController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $cekout = DB::table('cekout')->get();
        return view('pages.cekout', ['cekout' => $cekout]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('pages.tambah_datacekout');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        cekout::create([
            'tambah_datacekout' => $request->tambah_datacekout,
            'nama_barang' => $request->nama_barang,
            'jumlah_barang' => $request->jumlah_barang,
        ]);
        return redirect('cekout');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $datacekout= cekout::find($id);
        return view('pages.edit_datacekout', compact('datacekout'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        //$datacekout = cekout::find($id);
        cekout::create([
        'tambah_datacekout' => $request->tambah_datacekout,
        'nama_barang' => $request->nama_barang,
        'jumlah_barang' => $request->jumlah_barang,
    ]);
        return redirect('/cekin');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        cekout::find($id)->delete();
        return redirect()->back();
    }
}
