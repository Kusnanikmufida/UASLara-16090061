<?php

namespace App\Http\Controllers;

use App\suplier;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SuplierController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $suplier = DB::table('suplier')->get();
        return view('pages.suplier', ['suplier' => $suplier]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        suplier::create([
        'nama_suplier' => $request->nama_suplier,
        'alamat' => $request->alamat,
        'no_hp' => $request->no_hp,
    ]);

    return redirect('/suplier');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
       $datasuplier= suplier::find($id);
        return view('pages.edit_datasuplier', compact('datasuplier')); 
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
         $datasuplier = suplier::find($id);
        $datasuplier->update([
        'nama_suplier' => $request->nama_suplier,
        'alamat' => $request->alamat,
        'no_hp' => $request->no_hp,
    ]);
        return redirect('/datasuplier');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        suplier::find($id)->delete();
        return redirect()->back();
    }
}
