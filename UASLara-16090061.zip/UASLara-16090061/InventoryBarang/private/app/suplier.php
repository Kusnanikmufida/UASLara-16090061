<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * 
 */
class suplier extends Model
{
	protected $table='suplier';
	protected $guarded = [];
	protected $fillable = ['nama_suplier','alamat','no_hp'];
}