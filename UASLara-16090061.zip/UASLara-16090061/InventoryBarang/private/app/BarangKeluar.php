<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BarangKeluar extends Model
{
     protected $table='barangkeluar';
	protected $guarded = [];
	protected $fillable = ['tambah_databarangkeluar','tanggal_keluar','pengambilan','divisi','nama_barang','stok','jumlah_keluar','sisa_stok'];
}
