<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cekin extends Model
{
    protected $table='cekin';
	protected $guarded = [];
	protected $fillable = ['nama_barang','jumlah_barang'];
}
